open Bindlib

type term =
  | CstTrue
  | CstFalse
  | Var of term var
  | App of term * term
  | Abs of (term, term) binder
  | ITE of term * term * term

let rec remove e = function
  | [] -> []
  | h::t when h=e -> remove e t
  | h::t -> h :: (remove e t)

let rec fv : term -> string list = function
  | CstTrue | CstFalse -> []
  | Var(x) -> [name_of x]
  | Abs(f) ->
      let (x, t) = unbind f in
      remove (name_of x) (fv t)
  | App(t, u) ->
      (fv t) @ (fv u)
  | ITE(tc, tthen, telse) ->
      (fv tc) @ (fv tthen) @ (fv telse)

let rec string_of_term : term -> string = function
  | CstTrue -> "True"
  | CstFalse -> "False"
  | Var(x) -> name_of x
  | Abs(f) ->
      let (x, b) = unbind f
      in "(lam " ^ (name_of x) ^ "." ^ string_of_term b ^ ")"
  | App(t, u) ->
      "(" ^ string_of_term t ^ " " ^ string_of_term u ^ ")"
  | ITE(t, u, v) ->
      "if " ^ string_of_term t ^ " then " ^ string_of_term u ^ " else " ^
      string_of_term v

let _CstTrue : term box = box CstTrue
let _CstFalse : term box = box CstFalse
let _Var : term var -> term box = box_var
let _Abs : (term, term) binder box -> term box =
  box_apply (fun f -> Abs(f))
let _App : term box -> term box -> term box =
  box_apply2 (fun t u -> App(t, u))
let _ITE : term box -> term box -> term box -> term box =
  box_apply3 (fun t u v -> ITE(t, u, v))
(* wtf does box_apply[n] do exactly ??? *)

let t1 =
  let var_x = new_var (fun x -> Var(x)) "x"
  in App(Var(var_x), Var(var_x))

let var_x : term var = new_var (fun x -> Var(x)) "x"
let var_f : term var = new_var (fun x -> Var(x)) "f"

let _t2 : term box =
  _Abs (bind_var var_f
    (_Abs (bind_var var_x
      (_App (_Var var_f) (_App (_Var var_f) (_Var var_x))))))

let t2 : term = Bindlib.unbox _t2

let _t3 : term box =
  _Abs (bind_var var_f
    (_Abs (bind_var var_x
      (_App (_Var var_f) (_App (_Var var_x) (_Var var_x))))))

let t3 : term = Bindlib.unbox _t3

