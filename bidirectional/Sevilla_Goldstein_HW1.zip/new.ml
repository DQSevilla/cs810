let a = kjdnfkjd;

let a = 2


